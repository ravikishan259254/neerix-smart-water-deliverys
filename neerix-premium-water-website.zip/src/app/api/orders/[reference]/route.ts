import { db } from "@/db";
import { orders } from "@/db/schema";
import { ORDER_STAGES } from "@/lib/delivery";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ reference: string }> }
) {
  const { reference } = await params;
  try {
    const [row] = await db
      .select()
      .from(orders)
      .where(eq(orders.reference, reference))
      .limit(1);

    if (!row) {
      return Response.json({ ok: false, error: "Not found" }, { status: 404 });
    }

    // Simulate live progress based on time elapsed since order creation.
    const elapsedMin =
      (Date.now() - new Date(row.createdAt).getTime()) / 60000;
    const stageIndex = Math.min(
      ORDER_STAGES.length - 1,
      Math.floor(elapsedMin / 8)
    );
    const liveStatus = ORDER_STAGES[stageIndex];

    return Response.json({
      ok: true,
      order: { ...row, status: liveStatus, stageIndex },
    });
  } catch (err) {
    return Response.json({ ok: false, error: String(err) }, { status: 500 });
  }
}
