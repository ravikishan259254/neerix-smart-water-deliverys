import { db } from "@/db";
import { orders } from "@/db/schema";

export const dynamic = "force-dynamic";

function ref() {
  return (
    "NRX-" +
    Date.now().toString(36).toUpperCase().slice(-6) +
    Math.random().toString(36).toUpperCase().slice(2, 5)
  );
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const {
      customerName,
      email,
      phone,
      address,
      city,
      state,
      country,
      pincode,
      landmark,
      lat,
      lng,
      distanceKm,
      etaMinutes,
      items,
      subtotal,
      deliveryFee,
      tax,
      discount,
      total,
      currency,
      paymentMethod,
    } = body;

    if (!customerName || !email || !phone || !address || !items?.length) {
      return Response.json(
        { ok: false, error: "Missing required fields" },
        { status: 400 }
      );
    }

    const reference = ref();
    const [row] = await db
      .insert(orders)
      .values({
        reference,
        customerName,
        email,
        phone,
        address,
        city: city ?? null,
        state: state ?? null,
        country: country ?? null,
        pincode: pincode ?? null,
        landmark: landmark ?? null,
        lat: lat != null ? String(lat) : null,
        lng: lng != null ? String(lng) : null,
        distanceKm: distanceKm != null ? String(distanceKm) : null,
        etaMinutes: etaMinutes ?? null,
        items,
        subtotal: String(subtotal),
        deliveryFee: String(deliveryFee),
        tax: String(tax),
        discount: String(discount ?? 0),
        total: String(total),
        currency: currency ?? "INR",
        paymentMethod: paymentMethod ?? "Cash on Delivery",
        status: "Order Received",
      })
      .returning();

    return Response.json({ ok: true, reference: row.reference, order: row });
  } catch (err) {
    return Response.json({ ok: false, error: String(err) }, { status: 500 });
  }
}
