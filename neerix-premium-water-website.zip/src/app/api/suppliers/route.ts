import { db } from "@/db";
import { suppliers } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const b = await req.json();
    if (!b.plantName || !b.email || !b.phone || !b.license) {
      return Response.json(
        { ok: false, error: "Missing required fields" },
        { status: 400 }
      );
    }
    const [row] = await db
      .insert(suppliers)
      .values({
        plantName: b.plantName,
        contactName: b.contactName ?? b.plantName,
        email: b.email,
        phone: b.phone,
        license: b.license,
        waterType: b.waterType ?? "RO",
        capacity: b.capacity ?? "",
        serviceArea: b.serviceArea ?? "",
        status: "Pending Review",
      })
      .returning();
    return Response.json({ ok: true, supplier: row });
  } catch (err) {
    return Response.json({ ok: false, error: String(err) }, { status: 500 });
  }
}
