import { db } from "@/db";
import { contacts } from "@/db/schema";
import { sendContactEmail } from "@/lib/mailer";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const { name, email, phone, message } = await req.json();
    if (!name || !email || !message) {
      return Response.json(
        { ok: false, error: "Name, email and message are required" },
        { status: 400 }
      );
    }

    // Always persist so no message is ever lost.
    await db.insert(contacts).values({
      name,
      email,
      phone: phone ?? null,
      message,
    });

    // Attempt to deliver to the company Gmail (ravikishan3335@gmail.com).
    const { sent } = await sendContactEmail({ name, email, phone, message });

    return Response.json({
      ok: true,
      emailed: sent,
      message: sent
        ? "Message sent to our team! We'll respond within 24 hours."
        : "Message received. Our team will respond within 24 hours.",
    });
  } catch (err) {
    return Response.json({ ok: false, error: String(err) }, { status: 500 });
  }
}
