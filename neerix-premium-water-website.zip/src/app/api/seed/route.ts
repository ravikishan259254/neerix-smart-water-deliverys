import { db } from "@/db";
import { products } from "@/db/schema";
import { PRODUCTS } from "@/lib/products";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const existing = await db.select({ id: products.id }).from(products).limit(1);
    if (existing.length > 0) {
      return Response.json({ ok: true, seeded: false, message: "Already seeded" });
    }
    for (const p of PRODUCTS) {
      await db
        .insert(products)
        .values({
          slug: p.slug,
          name: p.name,
          category: p.category,
          description: p.description,
          price: String(p.price),
          unit: p.unit,
          image: p.image,
          badge: p.badge ?? null,
          popular: p.popular ?? false,
        })
        .onConflictDoNothing();
    }
    return Response.json({ ok: true, seeded: true, count: PRODUCTS.length });
  } catch (err) {
    return Response.json(
      { ok: false, error: String(err) },
      { status: 500 }
    );
  }
}

export async function POST() {
  return GET();
}
