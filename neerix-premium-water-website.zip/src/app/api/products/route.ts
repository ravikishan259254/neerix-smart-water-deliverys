import { db } from "@/db";
import { products } from "@/db/schema";
import { PRODUCTS } from "@/lib/products";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db.select().from(products).orderBy(desc(products.popular));
    if (rows.length === 0) {
      return Response.json({ products: PRODUCTS });
    }
    return Response.json({
      products: rows.map((r) => ({
        slug: r.slug,
        name: r.name,
        category: r.category,
        description: r.description,
        price: Number(r.price),
        unit: r.unit,
        image: r.image,
        img: PRODUCTS.find((p) => p.slug === r.slug)?.img,
        badge: r.badge ?? undefined,
        popular: r.popular,
      })),
    });
  } catch {
    return Response.json({ products: PRODUCTS });
  }
}
