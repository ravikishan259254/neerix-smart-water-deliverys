import { AppShell } from "@/components/AppShell";
import { Hero } from "@/components/Hero";
import { ProductsSection } from "@/components/ProductsSection";
import { DeliverySection } from "@/components/DeliverySection";
import { BusinessSection } from "@/components/BusinessSection";
import { ContactSection } from "@/components/ContactSection";
import {
  TrustBar,
  StatsSection,
  GlobalSection,
  AISection,
  ChainSection,
  TestimonialsSection,
  ExtrasSection,
  FAQSection,
} from "@/components/Sections";

export default function Home() {
  return (
    <AppShell>
      <Hero />
      <TrustBar />
      <ProductsSection />
      <DeliverySection />
      <StatsSection />
      <GlobalSection />
      <ChainSection />
      <AISection />
      <BusinessSection />
      <TestimonialsSection />
      <ExtrasSection />
      <FAQSection />
      <ContactSection />
    </AppShell>
  );
}
