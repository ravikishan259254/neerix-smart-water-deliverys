"use client";

import { Suspense, useCallback, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import { ORDER_STAGES } from "@/lib/delivery";

type OrderData = {
  reference: string;
  customerName: string;
  address: string;
  status: string;
  stageIndex: number;
  total: string;
  currency: string;
  etaMinutes: number | null;
  distanceKm: string | null;
  items: { name: string; qty: number; image: string }[];
};

function TrackInner() {
  const params = useSearchParams();
  const initial = params.get("ref") ?? "";
  const [ref, setRef] = useState(initial);
  const [order, setOrder] = useState<OrderData | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const lookup = useCallback(async (reference: string) => {
    if (!reference) return;
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`/api/orders/${reference}`);
      const data = await res.json();
      if (data.ok) {
        setOrder(data.order);
      } else {
        setError("Order not found. Check your reference number.");
        setOrder(null);
      }
    } catch {
      setError("Network error.");
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    if (initial) lookup(initial);
  }, [initial, lookup]);

  // Live refresh every 20s
  useEffect(() => {
    if (!order) return;
    const t = setInterval(() => lookup(order.reference), 20000);
    return () => clearInterval(t);
  }, [order, lookup]);

  return (
    <div className="pt-28 pb-20 px-4 min-h-screen">
      <div className="mx-auto max-w-3xl">
        <h1 className="text-3xl md:text-4xl font-bold text-cyan-50" style={{ fontFamily: "var(--font-sora)" }}>
          Track Your <span className="aqua-text">Delivery</span>
        </h1>
        <p className="text-cyan-200/60 mt-2">
          Enter your order reference to see live status.
        </p>

        <div className="flex gap-2 mt-6">
          <input
            value={ref}
            onChange={(e) => setRef(e.target.value)}
            placeholder="e.g. NRX-XXXXXX"
            className="flex-1 bg-white/5 border border-cyan-400/20 rounded-xl px-4 py-3 text-sm text-cyan-50 focus:outline-none focus:border-cyan-400/50"
          />
          <button onClick={() => lookup(ref.trim())} className="btn-primary rounded-xl px-6 text-sm">
            {loading ? "…" : "Track"}
          </button>
        </div>

        {error && <p className="text-red-400 text-sm mt-4">{error}</p>}

        {order && (
          <div className="glass-strong rounded-3xl p-7 mt-8">
            <div className="flex flex-wrap justify-between gap-4">
              <div>
                <p className="text-xs text-cyan-200/50">Reference</p>
                <p className="font-semibold text-cyan-50">{order.reference}</p>
              </div>
              <div>
                <p className="text-xs text-cyan-200/50">Customer</p>
                <p className="font-semibold text-cyan-50">{order.customerName}</p>
              </div>
              <div>
                <p className="text-xs text-cyan-200/50">Total</p>
                <p className="font-semibold aqua-text">
                  {order.currency} {order.total}
                </p>
              </div>
              {order.etaMinutes && (
                <div>
                  <p className="text-xs text-cyan-200/50">ETA</p>
                  <p className="font-semibold text-cyan-50">~{order.etaMinutes} min</p>
                </div>
              )}
            </div>

            <div className="mt-8">
              {ORDER_STAGES.map((s, i) => {
                const done = i <= order.stageIndex;
                const active = i === order.stageIndex;
                return (
                  <div key={s} className="flex gap-4 items-start">
                    <div className="flex flex-col items-center">
                      <span
                        className={`w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold ${
                          done
                            ? "bg-gradient-to-br from-cyan-400 to-sky-500 text-slate-950"
                            : "bg-white/10 text-cyan-200/40"
                        } ${active ? "pulse-ring" : ""}`}
                      >
                        {done ? "✓" : i + 1}
                      </span>
                      {i < ORDER_STAGES.length - 1 && (
                        <span
                          className={`w-0.5 h-10 ${done ? "bg-cyan-400/50" : "bg-white/10"}`}
                        />
                      )}
                    </div>
                    <div className="pb-6">
                      <p className={`font-medium ${done ? "text-cyan-50" : "text-cyan-200/40"}`}>
                        {s}
                      </p>
                      {active && (
                        <p className="text-xs text-cyan-300 mt-1">In progress…</p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="border-t border-cyan-400/10 pt-4 mt-2">
              <p className="text-xs text-cyan-200/50 mb-2">Items</p>
              <div className="flex flex-wrap gap-2">
                {order.items?.map((it, i) => (
                  <span key={i} className="glass rounded-full px-3 py-1.5 text-xs text-cyan-100">
                    {it.image} {it.name} ×{it.qty}
                  </span>
                ))}
              </div>
              <p className="text-xs text-cyan-200/50 mt-4">📍 {order.address}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function TrackPage() {
  return (
    <AppShell>
      <Suspense fallback={<div className="pt-40 text-center text-cyan-200/60">Loading…</div>}>
        <TrackInner />
      </Suspense>
    </AppShell>
  );
}
