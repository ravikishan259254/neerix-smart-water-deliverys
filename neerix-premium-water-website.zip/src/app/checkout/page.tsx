"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import { useStore } from "@/lib/store";
import { formatMoney, convert, CURRENCIES } from "@/lib/currency";
import { deliveryEstimate, haversine, HUB } from "@/lib/delivery";

const COUPONS: Record<string, number> = {
  NEERIX10: 0.1,
  PURE20: 0.2,
  WELCOME: 0.15,
};

const PAYMENTS = [
  ["Razorpay", "💳"],
  ["PhonePe", "📱"],
  ["UPI", "🏦"],
  ["Credit Card", "💠"],
  ["Debit Card", "🪪"],
  ["Net Banking", "🏛️"],
  ["Cash on Delivery", "💵"],
];

function CheckoutInner() {
  const router = useRouter();
  const { cart, subtotalINR, currency, clear, count } = useStore();
  const [distance, setDistance] = useState(4);
  const [payment, setPayment] = useState("Razorpay");
  const [coupon, setCoupon] = useState("");
  const [applied, setApplied] = useState<{ code: string; pct: number } | null>(null);
  const [placing, setPlacing] = useState(false);
  const [form, setForm] = useState({
    customerName: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    country: "India",
    pincode: "",
    landmark: "",
  });
  const [gpsMsg, setGpsMsg] = useState("");

  const est = deliveryEstimate(distance);
  const discountINR = applied ? subtotalINR * applied.pct : 0;
  const taxINR = (subtotalINR - discountINR) * 0.05;
  const totalINR = subtotalINR - discountINR + taxINR + est.fee;

  const applyCoupon = () => {
    const code = coupon.trim().toUpperCase();
    if (COUPONS[code]) setApplied({ code, pct: COUPONS[code] });
    else setApplied(null);
  };

  const useGps = () => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const d = haversine(HUB.lat, HUB.lng, pos.coords.latitude, pos.coords.longitude);
        setDistance(Math.min(40, Math.max(0.5, Math.round(d * 10) / 10)));
        setGpsMsg(`📍 Detected · ${d.toFixed(1)} km away`);
      },
      () => setGpsMsg("Location unavailable — set distance manually.")
    );
  };

  const placeOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setPlacing(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          distanceKm: distance,
          etaMinutes: est.etaMax,
          items: cart,
          subtotal: Math.round(convert(subtotalINR, currency) * 100) / 100,
          deliveryFee: Math.round(convert(est.fee, currency) * 100) / 100,
          tax: Math.round(convert(taxINR, currency) * 100) / 100,
          discount: Math.round(convert(discountINR, currency) * 100) / 100,
          total: Math.round(convert(totalINR, currency) * 100) / 100,
          currency,
          paymentMethod: payment,
        }),
      });
      const data = await res.json();
      if (data.ok) {
        clear();
        router.push(`/track?ref=${data.reference}`);
      } else {
        setPlacing(false);
        alert(data.error || "Order failed");
      }
    } catch {
      setPlacing(false);
      alert("Network error");
    }
  };

  if (count === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4 pt-28">
        <div className="glass-strong rounded-3xl p-12 text-center max-w-md">
          <div className="text-5xl mb-4">🛒</div>
          <h2 className="text-2xl font-bold text-cyan-50">Your cart is empty</h2>
          <p className="text-cyan-200/60 mt-2">Add some pure water to continue.</p>
          <Link href="/#products" className="btn-primary rounded-xl px-6 py-3 text-sm inline-block mt-6">
            Browse Products
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-28 pb-20 px-4">
      <div className="mx-auto max-w-6xl">
        <h1 className="text-3xl md:text-4xl font-bold text-cyan-50" style={{ fontFamily: "var(--font-sora)" }}>
          Secure <span className="aqua-text">Checkout</span>
        </h1>
        <div className="grid lg:grid-cols-3 gap-8 mt-8">
          {/* Left: forms */}
          <form onSubmit={placeOrder} className="lg:col-span-2 space-y-6">
            <div className="glass-strong rounded-3xl p-6">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-cyan-50">Delivery Address</h3>
                <button type="button" onClick={useGps} className="btn-ghost rounded-lg px-3 py-1.5 text-xs">
                  📍 Use GPS
                </button>
              </div>
              {gpsMsg && <p className="text-xs text-cyan-300 mt-2">{gpsMsg}</p>}
              <div className="grid sm:grid-cols-2 gap-3 mt-4">
                <Field label="Full Name" v={form.customerName} set={(v) => setForm({ ...form, customerName: v })} req />
                <Field label="Phone" v={form.phone} set={(v) => setForm({ ...form, phone: v })} req />
                <Field label="Email" type="email" v={form.email} set={(v) => setForm({ ...form, email: v })} req />
                <Field label="Pincode" v={form.pincode} set={(v) => setForm({ ...form, pincode: v })} />
                <div className="sm:col-span-2">
                  <Field label="Full Address" v={form.address} set={(v) => setForm({ ...form, address: v })} req />
                </div>
                <Field label="City" v={form.city} set={(v) => setForm({ ...form, city: v })} />
                <Field label="State" v={form.state} set={(v) => setForm({ ...form, state: v })} />
                <div>
                  <label className="text-xs text-cyan-200/70">Country</label>
                  <select
                    value={form.country}
                    onChange={(e) => setForm({ ...form, country: e.target.value })}
                    className="w-full mt-1 bg-white/5 border border-cyan-400/20 rounded-xl px-3 py-2.5 text-sm text-cyan-50 focus:outline-none"
                  >
                    {["India", "USA", "UAE", "UK", "Canada", "Australia"].map((c) => (
                      <option key={c} className="bg-slate-900">{c}</option>
                    ))}
                  </select>
                </div>
                <Field label="Landmark" v={form.landmark} set={(v) => setForm({ ...form, landmark: v })} />
              </div>

              <div className="mt-5">
                <label className="text-sm text-cyan-200/70 flex justify-between">
                  <span>Distance from hub</span>
                  <span className="text-cyan-300 font-semibold">
                    {distance} km · {est.etaText}
                  </span>
                </label>
                <input
                  type="range" min={0.5} max={40} step={0.5}
                  value={distance}
                  onChange={(e) => setDistance(Number(e.target.value))}
                  className="w-full mt-2 accent-cyan-400"
                />
              </div>
            </div>

            <div className="glass-strong rounded-3xl p-6">
              <h3 className="font-semibold text-cyan-50 mb-4">Payment Method</h3>
              <div className="grid sm:grid-cols-2 gap-3">
                {PAYMENTS.map(([p, icon]) => (
                  <button
                    key={p}
                    type="button"
                    onClick={() => setPayment(p)}
                    className={`flex items-center gap-3 rounded-xl px-4 py-3 text-sm border transition ${
                      payment === p
                        ? "border-cyan-400 bg-cyan-400/10 text-cyan-50"
                        : "border-cyan-400/15 text-cyan-200/70 hover:border-cyan-400/40"
                    }`}
                  >
                    <span className="text-lg">{icon}</span> {p}
                  </button>
                ))}
              </div>
              <div className="flex items-center gap-4 mt-5 text-xs text-cyan-200/50">
                <span className="flex items-center gap-1">🔒 100% Secure Payment</span>
                <span className="flex items-center gap-1">🛡️ Encrypted Checkout</span>
              </div>
            </div>
          </form>

          {/* Right: summary */}
          <div className="lg:col-span-1">
            <div className="glass-strong rounded-3xl p-6 sticky top-28">
              <h3 className="font-semibold text-cyan-50 mb-4">Order Summary</h3>
              <div className="space-y-3 max-h-52 overflow-y-auto">
                {cart.map((i) => (
                  <div key={i.slug} className="flex items-center gap-3 text-sm">
                    <span className="text-xl">{i.image}</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-cyan-50 truncate">{i.name}</p>
                      <p className="text-cyan-200/50 text-xs">
                        ×{i.qty}
                        {i.subscription !== "none" && ` · ${i.subscription}`}
                      </p>
                    </div>
                    <span className="text-cyan-200">
                      {formatMoney(i.price * i.qty, currency)}
                    </span>
                  </div>
                ))}
              </div>

              <div className="flex gap-2 mt-5">
                <input
                  value={coupon}
                  onChange={(e) => setCoupon(e.target.value)}
                  placeholder="Coupon code"
                  className="flex-1 bg-white/5 border border-cyan-400/20 rounded-xl px-3 py-2 text-sm text-cyan-50 focus:outline-none"
                />
                <button onClick={applyCoupon} className="btn-ghost rounded-xl px-4 text-sm">
                  Apply
                </button>
              </div>
              {applied && (
                <p className="text-emerald-300 text-xs mt-2">
                  ✅ {applied.code} applied · {applied.pct * 100}% off
                </p>
              )}
              {!applied && coupon && (
                <p className="text-cyan-200/40 text-xs mt-2">Try NEERIX10, PURE20 or WELCOME</p>
              )}

              <div className="border-t border-cyan-400/10 mt-5 pt-4 space-y-2 text-sm">
                <Row l="Subtotal" v={formatMoney(subtotalINR, currency)} />
                {discountINR > 0 && (
                  <Row l="Discount" v={`− ${formatMoney(discountINR, currency)}`} green />
                )}
                <Row l="Delivery Fee" v={formatMoney(est.fee, currency)} />
                <Row l="Tax (5%)" v={formatMoney(taxINR, currency)} />
                <div className="border-t border-cyan-400/10 pt-3 flex justify-between">
                  <span className="font-semibold text-cyan-50">Total</span>
                  <span className="font-bold text-lg aqua-text">
                    {formatMoney(totalINR, currency)}
                  </span>
                </div>
                <p className="text-[11px] text-cyan-200/40">
                  Paying in {CURRENCIES[currency].label} ({currency})
                </p>
              </div>

              <button
                onClick={placeOrder}
                disabled={placing}
                className="btn-primary rounded-xl w-full py-3.5 text-sm mt-5"
              >
                {placing ? "Placing Order…" : `Pay ${formatMoney(totalINR, currency)}`}
              </button>
              <p className="text-[11px] text-center text-cyan-200/50 mt-3">
                By ordering you agree to our Terms & Refund Policy.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Field({
  label, v, set, type = "text", req = false,
}: { label: string; v: string; set: (x: string) => void; type?: string; req?: boolean }) {
  return (
    <div>
      <label className="text-xs text-cyan-200/70">{label}</label>
      <input
        type={type}
        value={v}
        required={req}
        onChange={(e) => set(e.target.value)}
        className="w-full mt-1 bg-white/5 border border-cyan-400/20 rounded-xl px-3 py-2.5 text-sm text-cyan-50 focus:outline-none focus:border-cyan-400/50"
      />
    </div>
  );
}

function Row({ l, v, green = false }: { l: string; v: string; green?: boolean }) {
  return (
    <div className="flex justify-between">
      <span className="text-cyan-200/60">{l}</span>
      <span className={green ? "text-emerald-300" : "text-cyan-100"}>{v}</span>
    </div>
  );
}

export default function CheckoutPage() {
  return (
    <AppShell>
      <CheckoutInner />
    </AppShell>
  );
}
