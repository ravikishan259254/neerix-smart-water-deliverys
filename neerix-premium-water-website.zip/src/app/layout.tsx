import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Inter, Sora } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });
const sora = Sora({ subsets: ["latin"], variable: "--font-sora" });

export const metadata: Metadata = {
  title: "NEERIX — Pure Water. Pure Life. | Smart Water Delivery",
  description:
    "NEERIX delivers clean, pure, safe drinking water fast and reliably across India and worldwide. Order 20L jars, bottles, RO, mineral & tanker water anytime, anywhere.",
  keywords: [
    "water delivery",
    "NEERIX",
    "order water online",
    "20L jar water",
    "mineral water delivery",
    "RO water",
    "tanker water",
  ],
  openGraph: {
    title: "NEERIX — Pure Water. Pure Life.",
    description:
      "Fast, safe & trusted water delivery across India and worldwide.",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${inter.variable} ${sora.variable}`}>
      <body className="antialiased">{children}</body>
    </html>
  );
}
