"use client";

import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react";
import type { CurrencyCode } from "./currency";
import type { LangCode } from "./currency";

export type CartItem = {
  slug: string;
  name: string;
  image: string;
  img?: string;
  price: number; // base INR
  unit: string;
  qty: number;
  subscription: "none" | "daily" | "weekly" | "monthly";
};

type Store = {
  cart: CartItem[];
  addItem: (item: Omit<CartItem, "qty" | "subscription"> & {
    qty?: number;
    subscription?: CartItem["subscription"];
  }) => void;
  removeItem: (slug: string) => void;
  updateQty: (slug: string, qty: number) => void;
  updateSub: (slug: string, sub: CartItem["subscription"]) => void;
  clear: () => void;
  count: number;
  subtotalINR: number;
  currency: CurrencyCode;
  setCurrency: (c: CurrencyCode) => void;
  lang: LangCode;
  setLang: (l: LangCode) => void;
  drawerOpen: boolean;
  setDrawerOpen: (v: boolean) => void;
};

const StoreCtx = createContext<Store | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [currency, setCurrency] = useState<CurrencyCode>("INR");
  const [lang, setLang] = useState<LangCode>("en");
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const c = localStorage.getItem("neerix_cart");
      if (c) setCart(JSON.parse(c));
      const cur = localStorage.getItem("neerix_currency") as CurrencyCode | null;
      if (cur) setCurrency(cur);
      const lg = localStorage.getItem("neerix_lang") as LangCode | null;
      if (lg) setLang(lg);
    } catch {
      /* ignore */
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) localStorage.setItem("neerix_cart", JSON.stringify(cart));
  }, [cart, hydrated]);
  useEffect(() => {
    if (hydrated) localStorage.setItem("neerix_currency", currency);
  }, [currency, hydrated]);
  useEffect(() => {
    if (hydrated) localStorage.setItem("neerix_lang", lang);
  }, [lang, hydrated]);

  const addItem: Store["addItem"] = (item) => {
    setCart((prev) => {
      const found = prev.find((p) => p.slug === item.slug);
      if (found) {
        return prev.map((p) =>
          p.slug === item.slug
            ? { ...p, qty: p.qty + (item.qty ?? 1) }
            : p
        );
      }
      return [
        ...prev,
        {
          slug: item.slug,
          name: item.name,
          image: item.image,
          img: item.img,
          price: item.price,
          unit: item.unit,
          qty: item.qty ?? 1,
          subscription: item.subscription ?? "none",
        },
      ];
    });
    setDrawerOpen(true);
  };

  const removeItem = (slug: string) =>
    setCart((prev) => prev.filter((p) => p.slug !== slug));
  const updateQty = (slug: string, qty: number) =>
    setCart((prev) =>
      prev
        .map((p) => (p.slug === slug ? { ...p, qty: Math.max(1, qty) } : p))
        .filter((p) => p.qty > 0)
    );
  const updateSub = (slug: string, sub: CartItem["subscription"]) =>
    setCart((prev) =>
      prev.map((p) => (p.slug === slug ? { ...p, subscription: sub } : p))
    );
  const clear = () => setCart([]);

  const count = cart.reduce((s, i) => s + i.qty, 0);
  const subtotalINR = cart.reduce((s, i) => s + i.price * i.qty, 0);

  return (
    <StoreCtx.Provider
      value={{
        cart,
        addItem,
        removeItem,
        updateQty,
        updateSub,
        clear,
        count,
        subtotalINR,
        currency,
        setCurrency,
        lang,
        setLang,
        drawerOpen,
        setDrawerOpen,
      }}
    >
      {children}
    </StoreCtx.Provider>
  );
}

export function useStore() {
  const ctx = useContext(StoreCtx);
  if (!ctx) throw new Error("useStore must be used within StoreProvider");
  return ctx;
}
