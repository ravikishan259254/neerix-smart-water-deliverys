export type ProductOption = {
  label: string;
  price: number;
  note: string;
};

export type SeedProduct = {
  slug: string;
  name: string;
  category: string;
  description: string;
  price: number; // base price in INR
  unit: string;
  image: string; // emoji / key
  img: string; // real photo path
  badge?: string;
  popular?: boolean;
  options?: ProductOption[]; // e.g. event package sizes
  optionLabel?: string; // dropdown title
};

export const PRODUCTS: SeedProduct[] = [
  {
    slug: "20l-jar",
    name: "20L Jar Water",
    category: "Jars",
    description:
      "Refillable 20-litre purified drinking water jar. Perfect for homes and offices.",
    price: 60,
    unit: "per jar",
    image: "🫙",
    img: "/images/products/20l-jar.jpg",
    badge: "Best Seller",
    popular: true,
  },
  {
    slug: "1l-bottle",
    name: "1L Bottle Pack",
    category: "Bottles",
    description: "Pack of 12 crystal-clear 1-litre bottles. Sealed for purity.",
    price: 180,
    unit: "pack of 12",
    image: "🍶",
    img: "/images/products/1l-bottle.jpg",
    popular: true,
  },
  {
    slug: "500ml-bottle",
    name: "500ml Bottle Pack",
    category: "Bottles",
    description: "Pack of 24 handy 500ml bottles. Ideal on the go.",
    price: 240,
    unit: "pack of 24",
    image: "💧",
    img: "/images/products/500ml-bottle.jpg",
  },
  {
    slug: "mineral-water",
    name: "Premium Mineral Water",
    category: "Premium",
    description: "Naturally enriched mineral water with balanced electrolytes.",
    price: 320,
    unit: "pack of 12",
    image: "⛰️",
    img: "/images/products/mineral-water.jpg",
    badge: "Premium",
    popular: true,
  },
  {
    slug: "ro-water",
    name: "RO Purified Water",
    category: "Premium",
    description: "7-stage reverse-osmosis purified water. TDS optimized.",
    price: 90,
    unit: "20L jar",
    image: "🔬",
    img: "/images/products/ro-water.jpg",
  },
  {
    slug: "bulk-supply",
    name: "Bulk Water Supply",
    category: "Business",
    description: "Cost-effective bulk packages for apartments & communities.",
    price: 1200,
    unit: "25 jars",
    image: "📦",
    img: "/images/products/bulk-supply.jpg",
  },
  {
    slug: "office-supply",
    name: "Office Water Supply",
    category: "Business",
    description: "Scheduled office deliveries with dispensers & subscription.",
    price: 1500,
    unit: "monthly plan",
    image: "🏢",
    img: "/images/products/office-supply.jpg",
    badge: "Subscription",
  },
  {
    slug: "event-supply",
    name: "Event Water Supply",
    category: "Business",
    description: "Large-volume chilled water for weddings, events & functions.",
    price: 2500,
    unit: "per event",
    image: "🎪",
    img: "/images/products/event-supply.jpg",
    optionLabel: "Choose Event Package",
    options: [
      { label: "Small Event", price: 2500, note: "up to 100 guests" },
      { label: "Medium Event", price: 5000, note: "up to 300 guests" },
      { label: "Large Event", price: 9000, note: "up to 700 guests" },
      { label: "Grand Wedding", price: 15000, note: "1000+ guests" },
    ],
  },
  {
    slug: "tanker-delivery",
    name: "Tanker Water Delivery",
    category: "Business",
    description: "5,000L – 10,000L tanker delivery for construction & bulk needs.",
    price: 3500,
    unit: "per tanker",
    image: "🚚",
    img: "/images/products/tanker-delivery.jpg",
    badge: "Industrial",
  },
];
