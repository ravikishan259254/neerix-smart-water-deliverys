export function deliveryEstimate(distanceKm: number) {
  let etaMin: number;
  let etaMax: number;
  let fee: number;
  let label: string;
  if (distanceKm <= 5) {
    etaMin = 15;
    etaMax = 20;
    fee = 20;
    label = "Express Zone";
  } else if (distanceKm <= 15) {
    etaMin = 30;
    etaMax = 45;
    fee = 45;
    label = "City Zone";
  } else {
    etaMin = 60;
    etaMax = 120;
    fee = 90;
    label = "Extended Zone";
  }
  return { etaMin, etaMax, fee, label, etaText: `${etaMin}–${etaMax} min` };
}

export function haversine(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// NEERIX warehouse hub (Bengaluru central)
export const HUB = { lat: 12.9716, lng: 77.5946 };

export const ORDER_STAGES = [
  "Order Received",
  "Order Packed",
  "Out for Delivery",
  "Delivered",
] as const;
