import nodemailer from "nodemailer";

// Company inbox where contact messages are delivered.
export const CONTACT_EMAIL =
  process.env.CONTACT_EMAIL || "ravikishan3335@gmail.com";

/**
 * Sends a contact message to the company Gmail using Gmail SMTP.
 * Requires GMAIL_USER and GMAIL_APP_PASSWORD env vars (Gmail App Password).
 * Returns { sent: boolean } — if creds are missing it fails gracefully so the
 * message is still stored in the database and can be replied to.
 */
export async function sendContactEmail(input: {
  name: string;
  email: string;
  phone?: string;
  message: string;
}): Promise<{ sent: boolean; error?: string }> {
  const user = process.env.GMAIL_USER;
  const pass = process.env.GMAIL_APP_PASSWORD;

  if (!user || !pass) {
    return { sent: false, error: "Email credentials not configured" };
  }

  try {
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: { user, pass },
    });

    await transporter.sendMail({
      from: `"NEERIX Website" <${user}>`,
      to: CONTACT_EMAIL,
      replyTo: input.email,
      subject: `💧 New NEERIX enquiry from ${input.name}`,
      text: `Name: ${input.name}
Email: ${input.email}
Phone: ${input.phone || "—"}

Message:
${input.message}`,
      html: `
        <div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;background:#030916;color:#e6f6ff;border-radius:16px;overflow:hidden;border:1px solid rgba(56,189,248,0.2)">
          <div style="background:linear-gradient(120deg,#22d3ee,#0b3a6f);padding:20px 24px">
            <h2 style="margin:0;color:#041018">NEERIX — New Contact Message</h2>
          </div>
          <div style="padding:24px">
            <p style="margin:0 0 8px"><strong>Name:</strong> ${input.name}</p>
            <p style="margin:0 0 8px"><strong>Email:</strong> ${input.email}</p>
            <p style="margin:0 0 8px"><strong>Phone:</strong> ${input.phone || "—"}</p>
            <p style="margin:16px 0 6px"><strong>Message:</strong></p>
            <p style="margin:0;line-height:1.6;background:rgba(255,255,255,0.05);padding:14px;border-radius:12px">${input.message.replace(/\n/g, "<br/>")}</p>
          </div>
        </div>`,
    });

    return { sent: true };
  } catch (err) {
    return { sent: false, error: String(err) };
  }
}
