export type CurrencyCode = "INR" | "USD" | "EUR" | "AED";

export const CURRENCIES: Record<
  CurrencyCode,
  { symbol: string; rate: number; label: string }
> = {
  INR: { symbol: "₹", rate: 1, label: "Indian Rupee" },
  USD: { symbol: "$", rate: 0.012, label: "US Dollar" },
  EUR: { symbol: "€", rate: 0.011, label: "Euro" },
  AED: { symbol: "د.إ", rate: 0.044, label: "UAE Dirham" },
};

export function convert(inrAmount: number, code: CurrencyCode): number {
  return inrAmount * CURRENCIES[code].rate;
}

export function formatMoney(inrAmount: number, code: CurrencyCode): string {
  const value = convert(inrAmount, code);
  const { symbol } = CURRENCIES[code];
  const rounded =
    code === "INR" ? Math.round(value) : Math.round(value * 100) / 100;
  return `${symbol}${rounded.toLocaleString("en-IN", {
    minimumFractionDigits: code === "INR" ? 0 : 2,
    maximumFractionDigits: 2,
  })}`;
}

export const LANGUAGES = [
  { code: "en", label: "English", flag: "🇬🇧" },
  { code: "hi", label: "हिन्दी", flag: "🇮🇳" },
  { code: "bn", label: "বাংলা", flag: "🇧🇩" },
  { code: "ar", label: "العربية", flag: "🇦🇪" },
  { code: "es", label: "Español", flag: "🇪🇸" },
] as const;

export type LangCode = (typeof LANGUAGES)[number]["code"];
