import { Reveal } from "./Reveal";

export function TrustBar() {
  const items = [
    "ISO 9001 Certified",
    "Government Approved",
    "Purity Certificate",
    "Lab Tested Water",
    "FSSAI Registered",
    "Encrypted Checkout",
  ];
  return (
    <div className="relative border-y border-cyan-400/10 py-5 overflow-hidden">
      <div className="flex gap-12 marquee whitespace-nowrap w-max">
        {[...items, ...items].map((t, i) => (
          <span
            key={i}
            className="text-cyan-200/50 text-sm flex items-center gap-2"
          >
            <span className="text-cyan-400">✦</span> {t}
          </span>
        ))}
      </div>
    </div>
  );
}

export function StatsSection() {
  const stats = [
    ["1M+", "Happy Customers"],
    ["10M+", "Deliveries Made"],
    ["99%", "Satisfaction Rate"],
    ["24/7", "Live Support"],
  ];
  return (
    <section className="py-20 px-4">
      <div className="mx-auto max-w-6xl grid grid-cols-2 md:grid-cols-4 gap-5">
        {stats.map(([n, l], i) => (
          <Reveal key={l} delay={i * 80}>
            <div className="glass rounded-3xl p-8 text-center hover:border-cyan-400/40 transition">
              <p className="text-4xl md:text-5xl font-extrabold aqua-text">{n}</p>
              <p className="text-cyan-200/60 mt-2 text-sm">{l}</p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

export function GlobalSection() {
  const countries = [
    ["🇮🇳", "India", "Live"],
    ["🇺🇸", "USA", "Live"],
    ["🇦🇪", "UAE", "Live"],
    ["🇬🇧", "UK", "Live"],
    ["🇨🇦", "Canada", "Soon"],
    ["🇦🇺", "Australia", "Soon"],
  ];
  return (
    <section id="global" className="relative py-24 px-4">
      <div className="orb bg-sky-600/20 w-[30rem] h-[30rem] top-10 left-1/3" />
      <div className="mx-auto max-w-6xl relative">
        <Reveal>
          <div className="text-center max-w-2xl mx-auto">
            <p className="text-cyan-400 font-semibold tracking-widest text-sm uppercase">
              Global Delivery Expansion
            </p>
            <h2
              className="text-4xl md:text-5xl font-bold mt-3 text-cyan-50"
              style={{ fontFamily: "var(--font-sora)" }}
            >
              Pure Water, <span className="aqua-text">Worldwide</span>
            </h2>
            <p className="text-cyan-200/60 mt-4">
              Multi-language &amp; multi-currency support built for a global
              audience — English, हिन्दी, বাংলা, العربية, Español.
            </p>
          </div>
        </Reveal>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 mt-12">
          {countries.map(([flag, name, status], i) => (
            <Reveal key={name} delay={i * 70}>
              <div className="glass rounded-2xl p-6 text-center hover:-translate-y-1.5 transition">
                <div className="text-4xl">{flag}</div>
                <p className="font-semibold text-cyan-50 mt-2 text-sm">{name}</p>
                <span
                  className={`text-[10px] mt-2 inline-block rounded-full px-2 py-0.5 ${
                    status === "Live"
                      ? "bg-emerald-400/15 text-emerald-300 border border-emerald-400/30"
                      : "bg-amber-400/10 text-amber-300 border border-amber-400/25"
                  }`}
                >
                  {status}
                </span>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

export function AISection() {
  const feats = [
    ["🧠", "Smart Demand Prediction", "AI forecasts your reorder needs before you run out."],
    ["🗺️", "Auto Route Optimization", "Fastest routes computed in real-time for every delivery."],
    ["✨", "Personalized Recommendations", "Tailored products based on your usage patterns."],
    ["🤖", "NIA Chatbot Assistant", "24/7 AI support for orders, tracking and help."],
    ["🔔", "Real-time Notifications", "Push alerts at every step of your delivery."],
    ["📊", "Predictive Analytics", "Suppliers get demand insights & revenue forecasts."],
  ];
  return (
    <section className="py-24 px-4">
      <div className="mx-auto max-w-7xl">
        <Reveal>
          <div className="text-center max-w-2xl mx-auto">
            <p className="text-cyan-400 font-semibold tracking-widest text-sm uppercase">
              AI-Powered Platform
            </p>
            <h2
              className="text-4xl md:text-5xl font-bold mt-3 text-cyan-50"
              style={{ fontFamily: "var(--font-sora)" }}
            >
              Intelligence That <span className="aqua-text">Delivers</span>
            </h2>
          </div>
        </Reveal>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-12">
          {feats.map(([icon, t, d], i) => (
            <Reveal key={t} delay={i * 60}>
              <div className="glass rounded-3xl p-7 h-full hover:border-cyan-400/40 transition group">
                <div className="text-3xl w-14 h-14 flex items-center justify-center rounded-2xl bg-cyan-400/10 group-hover:aqua-glow transition">
                  {icon}
                </div>
                <h3 className="font-semibold text-cyan-50 text-lg mt-4">{t}</h3>
                <p className="text-cyan-200/60 text-sm mt-2">{d}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

export function ChainSection() {
  const steps = [
    ["🏭", "Supplier", "Certified water plants"],
    ["📦", "Warehouse", "Quality checked & stored"],
    ["🛵", "Delivery Partner", "Optimized last-mile"],
    ["🏠", "Customer", "Delivered fresh to you"],
  ];
  return (
    <section className="py-16 px-4">
      <div className="mx-auto max-w-6xl">
        <Reveal>
          <h2 className="text-center text-2xl md:text-3xl font-bold text-cyan-50 mb-12" style={{ fontFamily: "var(--font-sora)" }}>
            From Source to Sip — <span className="aqua-text">Our Supply Chain</span>
          </h2>
        </Reveal>
        <div className="flex flex-col md:flex-row items-stretch justify-between gap-4">
          {steps.map(([icon, t, d], i) => (
            <Reveal key={t} delay={i * 90} className="flex-1">
              <div className="glass rounded-2xl p-6 text-center h-full relative">
                <div className="text-4xl">{icon}</div>
                <p className="font-semibold text-cyan-50 mt-3">{t}</p>
                <p className="text-xs text-cyan-200/50 mt-1">{d}</p>
                {i < steps.length - 1 && (
                  <span className="hidden md:block absolute -right-4 top-1/2 -translate-y-1/2 text-cyan-400 text-2xl">
                    →
                  </span>
                )}
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

export function TestimonialsSection() {
  const reviews = [
    ["Aarav Mehta", "Mumbai", "Fastest water delivery I've ever used. My 20L jars arrive in under 20 minutes, every time!", 5],
    ["Sarah Khan", "Dubai", "The subscription feature is a lifesaver for our office. Reliable and premium quality.", 5],
    ["Rahul Das", "Kolkata", "Loved the live tracking and the AI assistant. Feels like a global-class product.", 5],
  ];
  return (
    <section className="py-24 px-4">
      <div className="mx-auto max-w-6xl">
        <Reveal>
          <div className="text-center max-w-2xl mx-auto">
            <p className="text-cyan-400 font-semibold tracking-widest text-sm uppercase">
              Ratings &amp; Reviews
            </p>
            <h2 className="text-4xl md:text-5xl font-bold mt-3 text-cyan-50" style={{ fontFamily: "var(--font-sora)" }}>
              Loved by <span className="aqua-text">Millions</span>
            </h2>
          </div>
        </Reveal>
        <div className="grid md:grid-cols-3 gap-6 mt-12">
          {reviews.map(([name, city, text, stars], i) => (
            <Reveal key={name as string} delay={i * 80}>
              <div className="glass rounded-3xl p-7 h-full">
                <div className="text-cyan-400 text-lg">{"★".repeat(stars as number)}</div>
                <p className="text-cyan-100/80 mt-4 text-sm leading-relaxed">“{text}”</p>
                <div className="flex items-center gap-3 mt-5">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-400 to-sky-600 flex items-center justify-center text-slate-950 font-bold">
                    {(name as string).charAt(0)}
                  </div>
                  <div>
                    <p className="text-cyan-50 text-sm font-semibold">{name}</p>
                    <p className="text-cyan-200/50 text-xs">{city}</p>
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

export function ExtrasSection() {
  const items = [
    ["🎁", "Referral Rewards", "Invite friends, earn free jars."],
    ["🏷️", "Coupons & Offers", "Save with seasonal discount codes."],
    ["⭐", "Loyalty Points", "Earn points on every order."],
    ["🏢", "Franchise Program", "Own a NEERIX hub in your city."],
    ["🤝", "Partner With Us", "Grow with our delivery network."],
    ["💼", "Careers", "Join our global mission."],
  ];
  return (
    <section className="py-16 px-4">
      <div className="mx-auto max-w-7xl">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {items.map(([icon, t, d], i) => (
            <Reveal key={t} delay={i * 50}>
              <div className="glass rounded-2xl p-6 flex items-start gap-4 hover:border-cyan-400/40 transition">
                <span className="text-2xl">{icon}</span>
                <div>
                  <p className="font-semibold text-cyan-50">{t}</p>
                  <p className="text-cyan-200/55 text-sm mt-1">{d}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

const FAQS = [
  ["How fast is delivery?", "Within 5 km your order arrives in 15–20 minutes. City zones take 30–45 minutes, and extended zones 1–2 hours — with live tracking throughout."],
  ["Which payment methods are supported?", "Razorpay, PhonePe, UPI, debit/credit cards, net banking and Cash on Delivery — all through an encrypted, 100% secure checkout."],
  ["Can I set up recurring delivery?", "Absolutely. Choose daily, weekly or monthly subscriptions on any product and manage them anytime from your dashboard."],
  ["Is the water quality certified?", "Every batch is lab-tested and ISO 9001, FSSAI and government approved with a purity certificate available on request."],
  ["Which countries do you serve?", "We're live in India, USA, UAE and UK, with Canada and Australia launching soon — plus multi-language and multi-currency support."],
];

export function FAQSection() {
  return (
    <section className="py-24 px-4">
      <div className="mx-auto max-w-3xl">
        <Reveal>
          <h2 className="text-center text-4xl md:text-5xl font-bold text-cyan-50" style={{ fontFamily: "var(--font-sora)" }}>
            Frequently Asked <span className="aqua-text">Questions</span>
          </h2>
        </Reveal>
        <div className="mt-10 space-y-3">
          {FAQS.map(([q, a], i) => (
            <Reveal key={q} delay={i * 50}>
              <details className="glass rounded-2xl p-5 group">
                <summary className="flex justify-between items-center cursor-pointer text-cyan-50 font-medium list-none">
                  {q}
                  <span className="text-cyan-400 group-open:rotate-45 transition text-xl">+</span>
                </summary>
                <p className="text-cyan-200/60 text-sm mt-3 leading-relaxed">{a}</p>
              </details>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
