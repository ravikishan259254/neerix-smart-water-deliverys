import Link from "next/link";
import { Logo } from "./Logo";

export function Footer() {
  const cols: [string, string[]][] = [
    ["Company", ["About Us", "Careers", "Blog", "Franchise", "Partner With Us"]],
    ["Products", ["20L Jars", "Bottles", "Mineral Water", "RO Water", "Tanker Delivery"]],
    ["Support", ["Contact", "FAQs", "Track Order", "Help Center", "Refund Policy"]],
    ["Legal", ["Privacy Policy", "Terms & Conditions", "Refund Policy", "Cookie Policy"]],
  ];
  return (
    <footer className="relative border-t border-cyan-400/10 pt-16 pb-8 px-4 mt-10">
      <div className="mx-auto max-w-7xl">
        <div className="grid md:grid-cols-2 lg:grid-cols-6 gap-10">
          <div className="lg:col-span-2">
            <Logo />
            <p className="text-cyan-200/60 text-sm mt-4 max-w-xs">
              Pure Water. Pure Life. The world's most trusted smart water
              delivery platform — from source to your door.
            </p>
            <div className="flex gap-3 mt-5">
              {["𝕏", "f", "in", "▶", "◎"].map((s, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-9 h-9 rounded-lg glass flex items-center justify-center text-cyan-200 hover:border-cyan-400/40 transition"
                >
                  {s}
                </a>
              ))}
            </div>
          </div>
          {cols.map(([title, links]) => (
            <div key={title}>
              <p className="font-semibold text-cyan-50 text-sm">{title}</p>
              <ul className="mt-4 space-y-2.5">
                {links.map((l) => (
                  <li key={l}>
                    <a href="#" className="text-cyan-200/55 text-sm hover:text-cyan-300 transition">
                      {l}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 glass rounded-2xl p-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div>
            <p className="font-semibold text-cyan-50">Stay in the flow 💧</p>
            <p className="text-cyan-200/55 text-sm">Get offers, tips and product updates.</p>
          </div>
          <div className="flex gap-2 w-full md:w-auto">
            <input
              placeholder="Your email"
              className="flex-1 md:w-64 bg-white/5 border border-cyan-400/20 rounded-xl px-4 py-2.5 text-sm text-cyan-50 focus:outline-none focus:border-cyan-400/50"
            />
            <button className="btn-primary rounded-xl px-5 py-2.5 text-sm">Subscribe</button>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-cyan-400/10 flex flex-col md:flex-row items-center justify-between gap-3 text-xs text-cyan-200/45">
          <p>© {new Date().getFullYear()} NEERIX Global. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <Link href="/track" className="hover:text-cyan-300">Track Order</Link>
            <a href="mailto:ravikishan3335@gmail.com" className="hover:text-cyan-300">
              ravikishan3335@gmail.com
            </a>
            <span>NEERIX Tower, Bengaluru</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
