"use client";

import { useState } from "react";
import { deliveryEstimate, HUB, haversine, ORDER_STAGES } from "@/lib/delivery";
import { useStore } from "@/lib/store";
import { formatMoney } from "@/lib/currency";
import { Reveal } from "./Reveal";

export function DeliverySection() {
  const { currency } = useStore();
  const [distance, setDistance] = useState(4);
  const [gpsMsg, setGpsMsg] = useState("");
  const [locating, setLocating] = useState(false);
  const est = deliveryEstimate(distance);

  const useGps = () => {
    if (!navigator.geolocation) {
      setGpsMsg("Geolocation not supported on this device.");
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const d = haversine(
          HUB.lat,
          HUB.lng,
          pos.coords.latitude,
          pos.coords.longitude
        );
        setDistance(Math.min(40, Math.max(0.5, Math.round(d * 10) / 10)));
        setGpsMsg(`📍 Location detected · ${d.toFixed(1)} km from nearest hub`);
        setLocating(false);
      },
      () => {
        setGpsMsg("Couldn't access location. Enter distance manually.");
        setLocating(false);
      }
    );
  };

  return (
    <section id="delivery" className="relative py-24 px-4">
      <div className="mx-auto max-w-7xl grid lg:grid-cols-2 gap-12 items-center">
        <Reveal>
          <p className="text-cyan-400 font-semibold tracking-widest text-sm uppercase">
            Location-Based Delivery
          </p>
          <h2
            className="text-4xl md:text-5xl font-bold mt-3 text-cyan-50"
            style={{ fontFamily: "var(--font-sora)" }}
          >
            Lightning-Fast <span className="aqua-text">Smart Delivery</span>
          </h2>
          <p className="text-cyan-200/60 mt-4 max-w-lg">
            Share your GPS location or set your distance to instantly see delivery
            time, charges and live status tracking — from our hub to your door.
          </p>

          <button
            onClick={useGps}
            className="btn-ghost rounded-xl px-6 py-3 text-sm mt-6"
          >
            {locating ? "Locating…" : "📍 Use My GPS Location"}
          </button>
          {gpsMsg && <p className="text-xs text-cyan-300 mt-3">{gpsMsg}</p>}

          <div className="mt-8">
            <label className="text-sm text-cyan-200/70 flex justify-between">
              <span>Distance from hub</span>
              <span className="text-cyan-300 font-semibold">{distance} km</span>
            </label>
            <input
              type="range"
              min={0.5}
              max={40}
              step={0.5}
              value={distance}
              onChange={(e) => setDistance(Number(e.target.value))}
              className="w-full mt-3 accent-cyan-400"
            />
          </div>

          <div className="grid grid-cols-3 gap-3 mt-6">
            <div className="glass rounded-2xl p-4 text-center">
              <p className="text-xs text-cyan-200/50">Zone</p>
              <p className="font-semibold text-cyan-50 text-sm mt-1">{est.label}</p>
            </div>
            <div className="glass rounded-2xl p-4 text-center">
              <p className="text-xs text-cyan-200/50">Est. Time</p>
              <p className="font-semibold aqua-text text-sm mt-1">{est.etaText}</p>
            </div>
            <div className="glass rounded-2xl p-4 text-center">
              <p className="text-xs text-cyan-200/50">Delivery Fee</p>
              <p className="font-semibold text-cyan-50 text-sm mt-1">
                {formatMoney(est.fee, currency)}
              </p>
            </div>
          </div>
        </Reveal>

        <Reveal delay={120}>
          <div className="glass-strong rounded-3xl p-6 relative overflow-hidden">
            {/* Map mock */}
            <div className="relative h-56 rounded-2xl overflow-hidden grid-lines bg-gradient-to-br from-sky-900/40 to-cyan-900/20 border border-cyan-400/15">
              <svg className="absolute inset-0 w-full h-full">
                <path
                  d="M40 200 C 140 120, 220 180, 320 60"
                  fill="none"
                  stroke="#22d3ee"
                  strokeWidth="3"
                  strokeDasharray="8 6"
                  className="marquee"
                  style={{ animation: "wave 3s linear infinite" }}
                />
              </svg>
              <span className="absolute left-8 bottom-8 flex flex-col items-center">
                <span className="text-2xl">🏭</span>
                <span className="text-[10px] text-cyan-200/70">Hub</span>
              </span>
              <span className="absolute right-8 top-6 flex flex-col items-center">
                <span className="text-2xl bob">📍</span>
                <span className="text-[10px] text-cyan-200/70">You</span>
              </span>
              <span className="absolute left-1/2 top-1/2 text-2xl -translate-x-1/2 -translate-y-1/2 bob">🚚</span>
            </div>

            <p className="text-sm font-semibold text-cyan-50 mt-5 mb-3">
              Live Delivery Status
            </p>
            <div className="space-y-3">
              {ORDER_STAGES.map((s, i) => (
                <div key={s} className="flex items-center gap-3">
                  <span
                    className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
                      i <= 2
                        ? "bg-gradient-to-br from-cyan-400 to-sky-500 text-slate-950"
                        : "bg-white/10 text-cyan-200/40"
                    }`}
                  >
                    {i <= 2 ? "✓" : i + 1}
                  </span>
                  <span
                    className={`text-sm ${
                      i <= 2 ? "text-cyan-50" : "text-cyan-200/40"
                    }`}
                  >
                    {s}
                  </span>
                  {i === 2 && (
                    <span className="ml-auto text-[10px] text-cyan-300 border border-cyan-400/30 rounded-full px-2 py-0.5">
                      Now
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
