"use client";

import { useMemo, useState } from "react";
import Image from "next/image";
import { useStore } from "@/lib/store";
import { formatMoney } from "@/lib/currency";
import { PRODUCTS, type SeedProduct } from "@/lib/products";
import { Reveal } from "./Reveal";

const CATS = ["All", "Jars", "Bottles", "Premium", "Business"];

function ProductCard({ p }: { p: SeedProduct }) {
  const { addItem, currency } = useStore();
  const [qty, setQty] = useState(1);
  const [sub, setSub] =
    useState<"none" | "daily" | "weekly" | "monthly">("none");
  const [optIdx, setOptIdx] = useState(0);

  const hasOptions = !!p.options?.length;
  const selectedOption = hasOptions ? p.options![optIdx] : null;
  const activePrice = selectedOption ? selectedOption.price : p.price;
  const activeUnit = selectedOption
    ? `${selectedOption.label} · ${selectedOption.note}`
    : p.unit;

  return (
    <div className="group glass rounded-3xl p-5 flex flex-col hover:border-cyan-400/40 transition-all duration-300 hover:-translate-y-1.5 relative overflow-hidden">
      <div className="absolute -right-8 -top-8 w-28 h-28 rounded-full bg-cyan-400/10 blur-2xl group-hover:bg-cyan-400/20 transition" />
      {p.badge && (
        <span className="absolute top-4 right-4 text-[10px] font-semibold uppercase tracking-wide bg-cyan-400/15 text-cyan-300 border border-cyan-400/30 rounded-full px-2.5 py-1">
          {p.badge}
        </span>
      )}
      <div className="relative mb-4 w-full h-44 rounded-2xl overflow-hidden bg-gradient-to-br from-cyan-400/10 to-sky-600/5 border border-cyan-400/15">
        <Image
          src={p.img}
          alt={p.name}
          fill
          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
          className="object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <span className="absolute bottom-2 left-2 text-2xl drop-shadow-lg">
          {p.image}
        </span>
      </div>
      <h3 className="font-semibold text-cyan-50 text-lg">{p.name}</h3>
      <p className="text-sm text-cyan-200/60 mt-1 flex-1">{p.description}</p>

      {hasOptions && (
        <div className="mt-3">
          <label className="text-[11px] text-cyan-300 font-medium">
            {p.optionLabel ?? "Choose option"}
          </label>
          <select
            value={optIdx}
            onChange={(e) => setOptIdx(Number(e.target.value))}
            className="w-full mt-1 bg-white/5 border border-cyan-400/20 rounded-xl px-3 py-2 text-sm text-cyan-100 focus:outline-none focus:border-cyan-400/50"
          >
            {p.options!.map((o, i) => (
              <option key={o.label} value={i} className="bg-slate-900">
                {o.label} · {o.note}
              </option>
            ))}
          </select>
        </div>
      )}

      <div className="flex items-end justify-between mt-4">
        <div>
          <p className="text-2xl font-bold aqua-text">
            {formatMoney(activePrice, currency)}
          </p>
          <p className="text-[11px] text-cyan-200/50">{activeUnit}</p>
        </div>
        <div className="flex items-center border border-cyan-400/25 rounded-xl overflow-hidden">
          <button
            onClick={() => setQty((q) => Math.max(1, q - 1))}
            className="px-3 py-1.5 text-cyan-200 hover:bg-cyan-400/10"
          >
            −
          </button>
          <span className="px-1 w-8 text-center text-cyan-50">{qty}</span>
          <button
            onClick={() => setQty((q) => q + 1)}
            className="px-3 py-1.5 text-cyan-200 hover:bg-cyan-400/10"
          >
            +
          </button>
        </div>
      </div>

      <select
        value={sub}
        onChange={(e) =>
          setSub(e.target.value as "none" | "daily" | "weekly" | "monthly")
        }
        className="mt-3 bg-white/5 border border-cyan-400/20 rounded-xl px-3 py-2 text-sm text-cyan-100 focus:outline-none focus:border-cyan-400/50"
      >
        <option value="none" className="bg-slate-900">One-time purchase</option>
        <option value="daily" className="bg-slate-900">Subscribe · Daily</option>
        <option value="weekly" className="bg-slate-900">Subscribe · Weekly</option>
        <option value="monthly" className="bg-slate-900">Subscribe · Monthly</option>
      </select>

      <button
        onClick={() =>
          addItem({
            slug: selectedOption ? `${p.slug}-${optIdx}` : p.slug,
            name: selectedOption
              ? `${p.name} — ${selectedOption.label}`
              : p.name,
            image: p.image,
            img: p.img,
            price: activePrice,
            unit: activeUnit,
            qty,
            subscription: sub,
          })
        }
        className="btn-primary rounded-xl mt-3 py-3 text-sm"
      >
        Add to Cart
      </button>
    </div>
  );
}

export function ProductsSection() {
  const [cat, setCat] = useState("All");
  const list = useMemo(
    () => (cat === "All" ? PRODUCTS : PRODUCTS.filter((p) => p.category === cat)),
    [cat]
  );

  return (
    <section id="products" className="relative py-24 px-4">
      <div className="mx-auto max-w-7xl">
        <Reveal>
          <div className="text-center max-w-2xl mx-auto">
            <p className="text-cyan-400 font-semibold tracking-widest text-sm uppercase">
              Smart Water Ordering
            </p>
            <h2 className="text-4xl md:text-5xl font-bold mt-3 text-cyan-50" style={{ fontFamily: "var(--font-sora)" }}>
              Choose Your <span className="aqua-text">Pure Water</span>
            </h2>
            <p className="text-cyan-200/60 mt-4">
              From 20L jars to industrial tankers — order once or subscribe for
              automatic delivery.
            </p>
          </div>
        </Reveal>

        <div className="flex flex-wrap justify-center gap-2 mt-10">
          {CATS.map((c) => (
            <button
              key={c}
              onClick={() => setCat(c)}
              className={`px-5 py-2 rounded-full text-sm font-medium transition ${
                cat === c
                  ? "btn-primary"
                  : "glass text-cyan-100/80 hover:border-cyan-400/40"
              }`}
            >
              {c}
            </button>
          ))}
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-10">
          {list.map((p, i) => (
            <Reveal key={p.slug} delay={i * 60}>
              <ProductCard p={p} />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
