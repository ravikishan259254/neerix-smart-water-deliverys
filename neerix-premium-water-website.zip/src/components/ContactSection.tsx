"use client";

import { useState } from "react";
import { Reveal } from "./Reveal";

export function ContactSection() {
  const [form, setForm] = useState({ name: "", email: "", phone: "", message: "" });
  const [status, setStatus] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [msg, setMsg] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus("loading");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (data.ok) {
        setStatus("done");
        setMsg(data.message);
        setForm({ name: "", email: "", phone: "", message: "" });
      } else {
        setStatus("error");
        setMsg(data.error || "Something went wrong.");
      }
    } catch {
      setStatus("error");
      setMsg("Network error. Please try again.");
    }
  };

  return (
    <section id="contact" className="relative py-24 px-4">
      <div className="mx-auto max-w-6xl grid lg:grid-cols-2 gap-10 items-center">
        <Reveal>
          <p className="text-cyan-400 font-semibold tracking-widest text-sm uppercase">
            Get In Touch
          </p>
          <h2
            className="text-4xl md:text-5xl font-bold mt-3 text-cyan-50"
            style={{ fontFamily: "var(--font-sora)" }}
          >
            We're Here <span className="aqua-text">24/7</span>
          </h2>
          <p className="text-cyan-200/60 mt-4 max-w-md">
            Questions, bulk orders, or partnerships? Send us a message and our
            team responds within 24 hours.
          </p>
          <div className="space-y-4 mt-8">
            <a
              href="mailto:ravikishan3335@gmail.com?subject=NEERIX%20Enquiry&body=Hello%20NEERIX%20team,"
              className="flex items-center gap-3 text-cyan-100/80 hover:text-cyan-300 transition"
            >
              <span className="w-10 h-10 rounded-xl bg-cyan-400/10 flex items-center justify-center">📧</span>
              <div>
                <p className="text-xs text-cyan-200/50">Email support</p>
                <p className="text-sm">ravikishan3335@gmail.com</p>
              </div>
            </a>
            <div className="flex items-center gap-3 text-cyan-100/80">
              <span className="w-10 h-10 rounded-xl bg-cyan-400/10 flex items-center justify-center">💬</span>
              <div>
                <p className="text-xs text-cyan-200/50">WhatsApp</p>
                <p className="text-sm">+91 90000 00000</p>
              </div>
            </div>
            <div className="flex items-center gap-3 text-cyan-100/80">
              <span className="w-10 h-10 rounded-xl bg-cyan-400/10 flex items-center justify-center">📍</span>
              <div>
                <p className="text-xs text-cyan-200/50">HQ</p>
                <p className="text-sm">NEERIX Tower, Bengaluru, India</p>
              </div>
            </div>
          </div>
        </Reveal>

        <Reveal delay={120}>
          <form onSubmit={submit} className="glass-strong rounded-3xl p-7 space-y-4">
            <div className="grid sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-cyan-200/70">Name</label>
                <input
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full mt-1 bg-white/5 border border-cyan-400/20 rounded-xl px-3 py-2.5 text-sm text-cyan-50 focus:outline-none focus:border-cyan-400/50"
                />
              </div>
              <div>
                <label className="text-xs text-cyan-200/70">Phone</label>
                <input
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  className="w-full mt-1 bg-white/5 border border-cyan-400/20 rounded-xl px-3 py-2.5 text-sm text-cyan-50 focus:outline-none focus:border-cyan-400/50"
                />
              </div>
            </div>
            <div>
              <label className="text-xs text-cyan-200/70">Email</label>
              <input
                type="email"
                required
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className="w-full mt-1 bg-white/5 border border-cyan-400/20 rounded-xl px-3 py-2.5 text-sm text-cyan-50 focus:outline-none focus:border-cyan-400/50"
              />
            </div>
            <div>
              <label className="text-xs text-cyan-200/70">Message</label>
              <textarea
                required
                rows={4}
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                className="w-full mt-1 bg-white/5 border border-cyan-400/20 rounded-xl px-3 py-2.5 text-sm text-cyan-50 focus:outline-none focus:border-cyan-400/50 resize-none"
              />
            </div>
            <button className="btn-primary rounded-xl w-full py-3 text-sm" disabled={status === "loading"}>
              {status === "loading" ? "Sending…" : "Send Message"}
            </button>
            <a
              href={`mailto:ravikishan3335@gmail.com?subject=${encodeURIComponent(
                `NEERIX Enquiry from ${form.name || "Website"}`
              )}&body=${encodeURIComponent(
                `Name: ${form.name}\nEmail: ${form.email}\nPhone: ${form.phone}\n\n${form.message}`
              )}`}
              className="btn-ghost rounded-xl w-full py-3 text-sm flex items-center justify-center"
            >
              ✉️ Or send directly via Gmail
            </a>
            {msg && (
              <p className={`text-sm text-center ${status === "done" ? "text-emerald-300" : "text-red-400"}`}>
                {msg}
              </p>
            )}
          </form>
        </Reveal>
      </div>
    </section>
  );
}
