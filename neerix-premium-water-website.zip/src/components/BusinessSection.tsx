"use client";

import { useState } from "react";
import { Reveal } from "./Reveal";

export function BusinessSection() {
  const [tab, setTab] = useState<"supplier" | "partner" | "customer">(
    "supplier"
  );
  const [form, setForm] = useState({
    plantName: "",
    contactName: "",
    email: "",
    phone: "",
    license: "",
    waterType: "RO",
    capacity: "",
    serviceArea: "",
  });
  const [status, setStatus] = useState<"idle" | "loading" | "done" | "error">(
    "idle"
  );

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus("loading");
    try {
      const res = await fetch("/api/suppliers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      setStatus(data.ok ? "done" : "error");
    } catch {
      setStatus("error");
    }
  };

  return (
    <section id="business" className="relative py-24 px-4">
      <div className="orb bg-cyan-600/15 w-[28rem] h-[28rem] -bottom-20 right-10" />
      <div className="mx-auto max-w-7xl relative">
        <Reveal>
          <div className="text-center max-w-2xl mx-auto">
            <p className="text-cyan-400 font-semibold tracking-widest text-sm uppercase">
              For Business
            </p>
            <h2
              className="text-4xl md:text-5xl font-bold mt-3 text-cyan-50"
              style={{ fontFamily: "var(--font-sora)" }}
            >
              Grow With <span className="aqua-text">NEERIX</span>
            </h2>
          </div>
        </Reveal>

        <div className="flex justify-center gap-2 mt-10 flex-wrap">
          {[
            ["supplier", "🏭 Supplier Panel"],
            ["partner", "🛵 Delivery Partner"],
            ["customer", "👤 Customer Dashboard"],
          ].map(([k, l]) => (
            <button
              key={k}
              onClick={() => setTab(k as typeof tab)}
              className={`px-5 py-2.5 rounded-full text-sm font-medium transition ${
                tab === k ? "btn-primary" : "glass text-cyan-100/80"
              }`}
            >
              {l}
            </button>
          ))}
        </div>

        <div className="mt-10 grid lg:grid-cols-2 gap-8 items-start">
          {tab === "supplier" && (
            <>
              <Reveal>
                <form onSubmit={submit} className="glass-strong rounded-3xl p-7 space-y-4">
                  <h3 className="font-semibold text-cyan-50 text-lg">
                    Register Your Water Plant
                  </h3>
                  <div className="grid sm:grid-cols-2 gap-3">
                    <Input label="Water Plant Name" value={form.plantName} onChange={(v) => setForm({ ...form, plantName: v })} required />
                    <Input label="Contact Person" value={form.contactName} onChange={(v) => setForm({ ...form, contactName: v })} />
                    <Input label="Email" type="email" value={form.email} onChange={(v) => setForm({ ...form, email: v })} required />
                    <Input label="Phone" value={form.phone} onChange={(v) => setForm({ ...form, phone: v })} required />
                    <Input label="License Number" value={form.license} onChange={(v) => setForm({ ...form, license: v })} required />
                    <div>
                      <label className="text-xs text-cyan-200/70">Water Type</label>
                      <select
                        value={form.waterType}
                        onChange={(e) => setForm({ ...form, waterType: e.target.value })}
                        className="w-full mt-1 bg-white/5 border border-cyan-400/20 rounded-xl px-3 py-2.5 text-sm text-cyan-50 focus:outline-none"
                      >
                        {["RO", "Mineral", "Spring", "Alkaline", "Distilled"].map((t) => (
                          <option key={t} value={t} className="bg-slate-900">{t}</option>
                        ))}
                      </select>
                    </div>
                    <Input label="Capacity (L/day)" value={form.capacity} onChange={(v) => setForm({ ...form, capacity: v })} />
                    <Input label="Service Area" value={form.serviceArea} onChange={(v) => setForm({ ...form, serviceArea: v })} />
                  </div>
                  <button className="btn-primary rounded-xl w-full py-3 text-sm" disabled={status === "loading"}>
                    {status === "loading" ? "Submitting…" : "Apply to Become a Supplier"}
                  </button>
                  {status === "done" && (
                    <p className="text-emerald-300 text-sm text-center">✅ Application received! Status: Pending Review.</p>
                  )}
                  {status === "error" && (
                    <p className="text-red-400 text-sm text-center">Something went wrong. Please try again.</p>
                  )}
                </form>
              </Reveal>
              <Reveal delay={120}>
                <DashboardMock
                  title="Supplier Dashboard"
                  cards={[
                    ["Orders Received", "1,284", "📥"],
                    ["Inventory", "8,400 L", "🫙"],
                    ["Active Deliveries", "36", "🚚"],
                    ["Revenue (mo)", "₹4.2L", "📈"],
                  ]}
                  rows={[
                    ["#NRX-8842", "20L Jar ×12", "Out for Delivery"],
                    ["#NRX-8839", "Mineral ×6", "Delivered"],
                    ["#NRX-8831", "Tanker ×1", "Packed"],
                  ]}
                />
              </Reveal>
            </>
          )}

          {tab === "partner" && (
            <>
              <Reveal>
                <div className="glass-strong rounded-3xl p-7 space-y-4">
                  <h3 className="font-semibold text-cyan-50 text-lg">Delivery Partner Console</h3>
                  <div className="glass rounded-2xl p-4">
                    <p className="text-xs text-cyan-200/50">Pickup</p>
                    <p className="text-cyan-50 text-sm font-medium">NEERIX Hub · Sector 4 Warehouse</p>
                  </div>
                  <div className="glass rounded-2xl p-4">
                    <p className="text-xs text-cyan-200/50">Drop-off</p>
                    <p className="text-cyan-50 text-sm font-medium">42 Lakeview Residency, Bengaluru</p>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="glass rounded-2xl p-4 text-center">
                      <p className="text-xs text-cyan-200/50">Optimized Route</p>
                      <p className="aqua-text font-semibold">6.2 km</p>
                    </div>
                    <div className="glass rounded-2xl p-4 text-center">
                      <p className="text-xs text-cyan-200/50">ETA</p>
                      <p className="aqua-text font-semibold">18 min</p>
                    </div>
                  </div>
                  <button className="btn-primary rounded-xl w-full py-3 text-sm">Confirm Delivery ✓</button>
                </div>
              </Reveal>
              <Reveal delay={120}>
                <DashboardMock
                  title="Today's Route"
                  cards={[
                    ["Stops", "14", "📍"],
                    ["Completed", "9", "✅"],
                    ["Earnings", "₹1,240", "💰"],
                    ["Rating", "4.9★", "⭐"],
                  ]}
                  rows={[
                    ["Stop 10", "Green Park", "Next"],
                    ["Stop 11", "MG Road", "Queued"],
                    ["Stop 12", "Indiranagar", "Queued"],
                  ]}
                />
              </Reveal>
            </>
          )}

          {tab === "customer" && (
            <>
              <Reveal>
                <DashboardMock
                  title="My Dashboard"
                  cards={[
                    ["Total Orders", "48", "📦"],
                    ["Loyalty Points", "1,250", "⭐"],
                    ["Active Subs", "2", "🔁"],
                    ["Saved Address", "3", "📍"],
                  ]}
                  rows={[
                    ["#NRX-9021", "20L Jar ×4", "Delivered"],
                    ["#NRX-9014", "Mineral ×12", "Out for Delivery"],
                    ["#NRX-9002", "RO ×2", "Delivered"],
                  ]}
                />
              </Reveal>
              <Reveal delay={120}>
                <div className="glass-strong rounded-3xl p-7 space-y-4">
                  <h3 className="font-semibold text-cyan-50 text-lg">Your Account</h3>
                  <p className="text-cyan-200/60 text-sm">
                    Create a free account to reorder in one tap, save addresses,
                    manage subscriptions and track deliveries in real time.
                  </p>
                  <div className="space-y-3">
                    {["Quick reorder", "Saved addresses", "Subscription management", "Live delivery tracking", "Loyalty & referral rewards"].map((f) => (
                      <div key={f} className="flex items-center gap-3 text-sm text-cyan-100/80">
                        <span className="text-cyan-400">✓</span> {f}
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-3">
                    <button className="btn-primary rounded-xl flex-1 py-3 text-sm">Sign Up Free</button>
                    <button className="btn-ghost rounded-xl flex-1 py-3 text-sm">Log In</button>
                  </div>
                </div>
              </Reveal>
            </>
          )}
        </div>
      </div>
    </section>
  );
}

function Input({
  label,
  value,
  onChange,
  type = "text",
  required = false,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  required?: boolean;
}) {
  return (
    <div>
      <label className="text-xs text-cyan-200/70">{label}</label>
      <input
        type={type}
        value={value}
        required={required}
        onChange={(e) => onChange(e.target.value)}
        className="w-full mt-1 bg-white/5 border border-cyan-400/20 rounded-xl px-3 py-2.5 text-sm text-cyan-50 placeholder:text-cyan-200/30 focus:outline-none focus:border-cyan-400/50"
      />
    </div>
  );
}

function DashboardMock({
  title,
  cards,
  rows,
}: {
  title: string;
  cards: [string, string, string][];
  rows: [string, string, string][];
}) {
  return (
    <div className="glass-strong rounded-3xl p-7">
      <h3 className="font-semibold text-cyan-50 text-lg mb-4">{title}</h3>
      <div className="grid grid-cols-2 gap-3">
        {cards.map(([l, v, icon]) => (
          <div key={l} className="glass rounded-2xl p-4">
            <div className="flex justify-between items-center">
              <span className="text-lg">{icon}</span>
            </div>
            <p className="text-xl font-bold aqua-text mt-2">{v}</p>
            <p className="text-xs text-cyan-200/50">{l}</p>
          </div>
        ))}
      </div>
      <div className="mt-4 space-y-2">
        {rows.map(([id, item, st]) => (
          <div key={id} className="flex items-center justify-between glass rounded-xl px-4 py-3 text-sm">
            <span className="text-cyan-200/70">{id}</span>
            <span className="text-cyan-100">{item}</span>
            <span className="text-[11px] text-cyan-300 border border-cyan-400/25 rounded-full px-2 py-0.5">{st}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
