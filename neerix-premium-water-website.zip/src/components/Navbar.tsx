"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Logo } from "./Logo";
import { useStore } from "@/lib/store";
import { CURRENCIES, LANGUAGES, type CurrencyCode } from "@/lib/currency";

const NAV = [
  { href: "/#products", label: "Order" },
  { href: "/#delivery", label: "Delivery" },
  { href: "/#global", label: "Global" },
  { href: "/track", label: "Track" },
  { href: "/#business", label: "Business" },
  { href: "/#contact", label: "Contact" },
];

export function Navbar() {
  const { count, setDrawerOpen, currency, setCurrency, lang, setLang } =
    useStore();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
        scrolled ? "py-2" : "py-4"
      }`}
    >
      <div className="mx-auto max-w-7xl px-4">
        <div
          className={`flex items-center justify-between rounded-2xl px-4 md:px-6 py-3 transition-all ${
            scrolled ? "glass-strong shadow-2xl" : ""
          }`}
        >
          <Link href="/" className="shrink-0">
            <Logo />
          </Link>

          <nav className="hidden lg:flex items-center gap-7">
            {NAV.map((n) => (
              <a
                key={n.href}
                href={n.href}
                className="text-sm text-cyan-100/80 hover:text-cyan-300 transition-colors font-medium"
              >
                {n.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-2 md:gap-3">
            <select
              value={lang}
              onChange={(e) => setLang(e.target.value as typeof lang)}
              className="hidden sm:block bg-transparent text-xs text-cyan-100/80 border border-cyan-400/20 rounded-lg px-2 py-1.5 focus:outline-none cursor-pointer"
              aria-label="Language"
            >
              {LANGUAGES.map((l) => (
                <option key={l.code} value={l.code} className="bg-slate-900">
                  {l.flag} {l.label}
                </option>
              ))}
            </select>
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
              className="hidden sm:block bg-transparent text-xs text-cyan-100/80 border border-cyan-400/20 rounded-lg px-2 py-1.5 focus:outline-none cursor-pointer"
              aria-label="Currency"
            >
              {(Object.keys(CURRENCIES) as CurrencyCode[]).map((c) => (
                <option key={c} value={c} className="bg-slate-900">
                  {CURRENCIES[c].symbol} {c}
                </option>
              ))}
            </select>

            <button
              onClick={() => setDrawerOpen(true)}
              className="relative rounded-xl border border-cyan-400/30 p-2.5 hover:bg-cyan-400/10 transition"
              aria-label="Cart"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-cyan-200">
                <path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z" />
                <path d="M3 6h18M16 10a4 4 0 0 1-8 0" />
              </svg>
              {count > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-cyan-400 text-slate-950 text-[10px] font-bold rounded-full min-w-[18px] h-[18px] flex items-center justify-center px-1">
                  {count}
                </span>
              )}
            </button>

            <a
              href="/#products"
              className="hidden md:inline-flex btn-primary rounded-xl px-5 py-2.5 text-sm"
            >
              Order Now
            </a>

            <button
              className="lg:hidden rounded-xl border border-cyan-400/30 p-2.5 text-cyan-200"
              onClick={() => setOpen((o) => !o)}
              aria-label="Menu"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                {open ? <path d="M18 6 6 18M6 6l12 12" /> : <path d="M3 12h18M3 6h18M3 18h18" />}
              </svg>
            </button>
          </div>
        </div>

        {open && (
          <div className="lg:hidden mt-2 glass-strong rounded-2xl p-4 flex flex-col gap-1">
            {NAV.map((n) => (
              <a
                key={n.href}
                href={n.href}
                onClick={() => setOpen(false)}
                className="px-3 py-2.5 rounded-lg text-cyan-100/90 hover:bg-cyan-400/10"
              >
                {n.label}
              </a>
            ))}
            <div className="flex gap-2 mt-2">
              <select
                value={lang}
                onChange={(e) => setLang(e.target.value as typeof lang)}
                className="flex-1 bg-transparent text-xs text-cyan-100 border border-cyan-400/20 rounded-lg px-2 py-2"
              >
                {LANGUAGES.map((l) => (
                  <option key={l.code} value={l.code} className="bg-slate-900">
                    {l.flag} {l.label}
                  </option>
                ))}
              </select>
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
                className="flex-1 bg-transparent text-xs text-cyan-100 border border-cyan-400/20 rounded-lg px-2 py-2"
              >
                {(Object.keys(CURRENCIES) as CurrencyCode[]).map((c) => (
                  <option key={c} value={c} className="bg-slate-900">
                    {CURRENCIES[c].symbol} {c}
                  </option>
                ))}
              </select>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
