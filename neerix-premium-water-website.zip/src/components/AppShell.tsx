"use client";

import type { ReactNode } from "react";
import { StoreProvider } from "@/lib/store";
import { Navbar } from "./Navbar";
import { Footer } from "./Footer";
import { Floating } from "./Floating";
import { CartDrawer } from "./CartDrawer";

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <StoreProvider>
      <Navbar />
      <main className="relative">{children}</main>
      <Footer />
      <Floating />
      <CartDrawer />
    </StoreProvider>
  );
}
