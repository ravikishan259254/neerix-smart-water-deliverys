export function Logo({ size = 34 }: { size?: number }) {
  return (
    <span className="flex items-center gap-2.5">
      <span
        className="relative inline-flex items-center justify-center rounded-2xl"
        style={{ width: size, height: size }}
      >
        <svg
          viewBox="0 0 48 48"
          width={size}
          height={size}
          className="drop-shadow-[0_0_10px_rgba(34,211,238,0.7)]"
        >
          <defs>
            <linearGradient id="ndrop" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0" stopColor="#a5f3fc" />
              <stop offset="0.5" stopColor="#22d3ee" />
              <stop offset="1" stopColor="#0b3a6f" />
            </linearGradient>
          </defs>
          <path
            d="M24 3C24 3 8 21 8 32a16 16 0 0 0 32 0C40 21 24 3 24 3Z"
            fill="url(#ndrop)"
          />
          <path
            d="M17 30c0 5 3.5 8.5 7 9"
            stroke="#ffffff"
            strokeWidth="2.4"
            strokeLinecap="round"
            fill="none"
            opacity="0.85"
          />
        </svg>
      </span>
      <span
        className="font-bold tracking-tight aqua-text"
        style={{ fontSize: size * 0.62, fontFamily: "var(--font-sora)" }}
      >
        NEERIX
      </span>
    </span>
  );
}
