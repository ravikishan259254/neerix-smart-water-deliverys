"use client";

import { useState } from "react";

const WA_NUMBER = "919000000000";
const WA_MSG = encodeURIComponent("Hello NEERIX, I want to order water.");

type Msg = { from: "bot" | "user"; text: string };

const QUICK = [
  "How do I order?",
  "Delivery time?",
  "Available areas?",
  "Payment options?",
];

function botReply(q: string): string {
  const t = q.toLowerCase();
  if (t.includes("order"))
    return "Tap “Order Now”, pick your water products, choose quantity & subscription, then checkout. You can also order instantly on WhatsApp! 💧";
  if (t.includes("time") || t.includes("deliver"))
    return "Delivery is 15–20 min within 5 km, 30–45 min within 15 km, and 1–2 hrs beyond. Live tracking is included with every order. 🚚";
  if (t.includes("area") || t.includes("location"))
    return "We serve across India and are expanding to USA, UAE, UK, Canada & Australia. Enable GPS at checkout to check your zone. 🌍";
  if (t.includes("pay"))
    return "We accept Razorpay, PhonePe, UPI, cards, net banking and Cash on Delivery — all with encrypted checkout. 🔒";
  if (t.includes("price") || t.includes("cost"))
    return "20L jars start at ₹60. Bottles, mineral, RO, bulk, office, event & tanker options available. Prices adapt to your currency! 💰";
  if (t.includes("subscri"))
    return "Yes! Set daily, weekly or monthly auto-delivery on any product and manage it from your dashboard. 📅";
  return "I'm NIA, your NEERIX AI assistant. Ask me about ordering, delivery, pricing, areas or payments — or start a WhatsApp chat for instant help! 💠";
}

export function Floating() {
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState<Msg[]>([
    {
      from: "bot",
      text: "👋 Hi! I'm NIA, NEERIX's AI assistant. How can I help you today?",
    },
  ]);
  const [input, setInput] = useState("");

  const send = (text: string) => {
    if (!text.trim()) return;
    setMsgs((m) => [...m, { from: "user", text }]);
    setInput("");
    setTimeout(() => {
      setMsgs((m) => [...m, { from: "bot", text: botReply(text) }]);
    }, 500);
  };

  return (
    <>
      {/* Chatbot panel */}
      {open && (
        <div className="fixed bottom-28 right-4 sm:right-6 z-50 w-[92vw] max-w-sm glass-strong rounded-3xl overflow-hidden shadow-2xl border border-cyan-400/25">
          <div className="bg-gradient-to-r from-cyan-500/20 to-sky-500/10 p-4 flex items-center gap-3 border-b border-cyan-400/20">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-300 to-sky-600 flex items-center justify-center text-lg">
              🤖
            </div>
            <div>
              <p className="font-semibold text-cyan-50 text-sm">NIA · AI Assistant</p>
              <p className="text-[11px] text-emerald-300 flex items-center gap-1">
                <span className="w-2 h-2 bg-emerald-400 rounded-full" /> Online 24/7
              </p>
            </div>
            <button
              onClick={() => setOpen(false)}
              className="ml-auto text-cyan-200/70 hover:text-cyan-200"
              aria-label="Close chat"
            >
              ✕
            </button>
          </div>
          <div className="p-4 h-72 overflow-y-auto flex flex-col gap-3">
            {msgs.map((m, i) => (
              <div
                key={i}
                className={`max-w-[85%] px-3.5 py-2.5 rounded-2xl text-sm leading-relaxed ${
                  m.from === "bot"
                    ? "self-start bg-white/5 text-cyan-50 rounded-tl-sm"
                    : "self-end bg-gradient-to-br from-cyan-400 to-sky-500 text-slate-950 font-medium rounded-tr-sm"
                }`}
              >
                {m.text}
              </div>
            ))}
          </div>
          <div className="px-3 pb-2 flex flex-wrap gap-1.5">
            {QUICK.map((q) => (
              <button
                key={q}
                onClick={() => send(q)}
                className="text-[11px] px-2.5 py-1 rounded-full border border-cyan-400/25 text-cyan-100/80 hover:bg-cyan-400/10"
              >
                {q}
              </button>
            ))}
          </div>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              send(input);
            }}
            className="p-3 border-t border-cyan-400/15 flex gap-2"
          >
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type a message…"
              className="flex-1 bg-white/5 border border-cyan-400/20 rounded-xl px-3 py-2 text-sm text-cyan-50 placeholder:text-cyan-200/40 focus:outline-none focus:border-cyan-400/50"
            />
            <button type="submit" className="btn-primary rounded-xl px-4 text-sm">
              Send
            </button>
          </form>
        </div>
      )}

      {/* Floating buttons */}
      <div className="fixed bottom-6 right-4 sm:right-6 z-50 flex flex-col gap-3">
        <button
          onClick={() => setOpen((o) => !o)}
          className="w-14 h-14 rounded-full bg-gradient-to-br from-cyan-400 to-sky-600 flex items-center justify-center text-2xl shadow-xl aqua-glow hover:scale-105 transition"
          aria-label="AI Chat"
        >
          {open ? "✕" : "🤖"}
        </button>
        <a
          href={`https://wa.me/${WA_NUMBER}?text=${WA_MSG}`}
          target="_blank"
          rel="noopener noreferrer"
          className="w-14 h-14 rounded-full bg-[#25D366] flex items-center justify-center shadow-xl pulse-ring hover:scale-105 transition"
          aria-label="WhatsApp Order"
        >
          <svg width="28" height="28" viewBox="0 0 24 24" fill="#fff">
            <path d="M17.5 14.4c-.3-.2-1.7-.9-2-1-.3-.1-.5-.2-.7.1-.2.3-.7 1-.9 1.2-.2.2-.3.2-.6.1-.3-.2-1.2-.5-2.4-1.4-.9-.8-1.5-1.7-1.6-2-.2-.3 0-.5.1-.6l.5-.5c.1-.2.2-.3.3-.5.1-.2 0-.4 0-.5 0-.2-.7-1.6-.9-2.2-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.5.1-.8.4-.3.3-1 1-1 2.5s1.1 2.9 1.2 3.1c.2.2 2.1 3.3 5.2 4.6.7.3 1.3.5 1.7.6.7.2 1.4.2 1.9.1.6-.1 1.7-.7 2-1.4.2-.7.2-1.2.2-1.4-.1-.1-.3-.2-.6-.3ZM12 2a10 10 0 0 0-8.6 15l-1.3 4.7 4.8-1.3A10 10 0 1 0 12 2Z" />
          </svg>
        </a>
      </div>
    </>
  );
}
