"use client";

import Image from "next/image";
import { useMemo } from "react";

const WA_NUMBER = "919000000000";
const WA_MSG = encodeURIComponent("Hello NEERIX, I want to order water.");

export function Hero() {
  const drops = useMemo(
    () =>
      Array.from({ length: 22 }).map((_, i) => ({
        left: Math.random() * 100,
        size: 4 + Math.random() * 10,
        delay: Math.random() * 12,
        dur: 10 + Math.random() * 14,
        op: 0.15 + Math.random() * 0.4,
      })),
    []
  );

  return (
    <section className="relative min-h-screen flex items-center pt-28 pb-16 px-4 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 grid-lines opacity-60" />
      <div className="orb bg-cyan-500/40 w-[38rem] h-[38rem] -top-40 -left-40" />
      <div
        className="orb bg-sky-600/30 w-[30rem] h-[30rem] top-40 -right-32"
        style={{ animationDelay: "3s" }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#030916]" />

      {/* Falling droplets */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {drops.map((d, i) => (
          <span
            key={i}
            className="absolute rounded-full bg-cyan-300"
            style={{
              left: `${d.left}%`,
              bottom: `-20px`,
              width: d.size,
              height: d.size * 1.4,
              opacity: d.op,
              borderRadius: "50% 50% 50% 50% / 60% 60% 40% 40%",
              filter: "blur(0.4px)",
              animation: `drift ${d.dur}s linear ${d.delay}s infinite`,
            }}
          />
        ))}
      </div>

      <div className="relative mx-auto max-w-7xl grid lg:grid-cols-2 gap-12 items-center z-10">
        <div className="reveal in">
          <div className="inline-flex items-center gap-2 glass rounded-full px-4 py-1.5 text-xs text-cyan-200 mb-6">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            Trusted by 1M+ customers · Now delivering in 6 countries
          </div>
          <h1
            className="text-5xl md:text-6xl xl:text-7xl font-extrabold leading-[1.05] text-cyan-50"
            style={{ fontFamily: "var(--font-sora)" }}
          >
            Order <span className="aqua-text">Pure Water</span>
            <br />
            Anytime, Anywhere
          </h1>
          <p className="text-lg text-cyan-200/70 mt-6 max-w-xl">
            Fast, Safe &amp; Trusted Water Delivery Across India and Worldwide.
            <span className="text-cyan-300 font-medium"> Pure Water. Pure Life.</span>
          </p>

          <div className="flex flex-wrap gap-3 mt-8">
            <a href="#products" className="btn-primary rounded-xl px-7 py-3.5 text-sm">
              💧 Order Now
            </a>
            <a href="#contact" className="btn-ghost rounded-xl px-7 py-3.5 text-sm">
              Contact Us
            </a>
            <a
              href={`https://wa.me/${WA_NUMBER}?text=${WA_MSG}`}
              target="_blank"
              rel="noopener noreferrer"
              className="rounded-xl px-7 py-3.5 text-sm font-semibold bg-[#25D366]/90 text-white hover:bg-[#25D366] transition flex items-center gap-2"
            >
              WhatsApp Order
            </a>
          </div>

          <div className="flex flex-wrap gap-6 mt-10">
            {[
              ["10M+", "Deliveries"],
              ["99%", "Satisfaction"],
              ["24/7", "Support"],
              ["ISO", "Certified"],
            ].map(([n, l]) => (
              <div key={l}>
                <p className="text-2xl font-bold aqua-text">{n}</p>
                <p className="text-xs text-cyan-200/50">{l}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="relative reveal in flex justify-center">
          <div className="absolute inset-0 bg-cyan-400/20 blur-3xl rounded-full" />
          <div className="relative bob">
            <Image
              src="/images/hero-water.jpg"
              alt="Pure NEERIX water droplet"
              width={560}
              height={560}
              priority
              className="rounded-[2.5rem] border border-cyan-400/20 shadow-2xl object-cover"
            />
            <div className="absolute -bottom-5 -left-5 glass-strong rounded-2xl p-4 flex items-center gap-3 aqua-glow">
              <span className="text-2xl">🚚</span>
              <div>
                <p className="text-xs text-cyan-200/60">Live delivery</p>
                <p className="text-sm font-semibold text-cyan-50">Out for delivery · 12 min</p>
              </div>
            </div>
            <div className="absolute -top-5 -right-4 glass-strong rounded-2xl p-3 flex items-center gap-2">
              <span className="text-xl">✅</span>
              <p className="text-xs font-medium text-cyan-50">100% Purity Tested</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
