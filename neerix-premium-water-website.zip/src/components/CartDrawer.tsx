"use client";

import Link from "next/link";
import Image from "next/image";
import { useStore } from "@/lib/store";
import { formatMoney } from "@/lib/currency";

const SUBS: { value: "none" | "daily" | "weekly" | "monthly"; label: string }[] =
  [
    { value: "none", label: "One-time" },
    { value: "daily", label: "Daily" },
    { value: "weekly", label: "Weekly" },
    { value: "monthly", label: "Monthly" },
  ];

export function CartDrawer() {
  const {
    cart,
    drawerOpen,
    setDrawerOpen,
    updateQty,
    updateSub,
    removeItem,
    subtotalINR,
    currency,
    count,
  } = useStore();

  return (
    <>
      <div
        className={`fixed inset-0 z-[60] bg-black/60 backdrop-blur-sm transition-opacity ${
          drawerOpen ? "opacity-100" : "opacity-0 pointer-events-none"
        }`}
        onClick={() => setDrawerOpen(false)}
      />
      <aside
        className={`fixed top-0 right-0 z-[70] h-full w-[92vw] max-w-md glass-strong border-l border-cyan-400/20 flex flex-col transition-transform duration-300 ${
          drawerOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex items-center justify-between p-5 border-b border-cyan-400/15">
          <h3 className="font-semibold text-lg text-cyan-50">
            Your Cart <span className="text-cyan-400">({count})</span>
          </h3>
          <button
            onClick={() => setDrawerOpen(false)}
            className="text-cyan-200/70 hover:text-cyan-200 text-xl"
            aria-label="Close"
          >
            ✕
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {cart.length === 0 && (
            <div className="text-center py-20 text-cyan-200/60">
              <div className="text-5xl mb-3">💧</div>
              Your cart is empty.
              <br />
              Add pure water to get started.
            </div>
          )}
          {cart.map((item) => (
            <div
              key={item.slug}
              className="glass rounded-2xl p-4 flex gap-3"
            >
              <div className="relative w-12 h-12 rounded-xl bg-cyan-400/10 shrink-0 overflow-hidden flex items-center justify-center text-2xl">
                {item.img ? (
                  <Image src={item.img} alt={item.name} fill sizes="48px" className="object-cover" />
                ) : (
                  item.image
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex justify-between gap-2">
                  <p className="font-medium text-cyan-50 text-sm">{item.name}</p>
                  <button
                    onClick={() => removeItem(item.slug)}
                    className="text-cyan-200/50 hover:text-red-400 text-xs"
                  >
                    Remove
                  </button>
                </div>
                <p className="text-xs text-cyan-200/50">{item.unit}</p>
                <div className="flex items-center gap-2 mt-2">
                  <div className="flex items-center border border-cyan-400/25 rounded-lg overflow-hidden">
                    <button
                      onClick={() => updateQty(item.slug, item.qty - 1)}
                      className="px-2.5 py-1 text-cyan-200 hover:bg-cyan-400/10"
                    >
                      −
                    </button>
                    <span className="px-2 text-sm text-cyan-50 w-8 text-center">
                      {item.qty}
                    </span>
                    <button
                      onClick={() => updateQty(item.slug, item.qty + 1)}
                      className="px-2.5 py-1 text-cyan-200 hover:bg-cyan-400/10"
                    >
                      +
                    </button>
                  </div>
                  <select
                    value={item.subscription}
                    onChange={(e) =>
                      updateSub(
                        item.slug,
                        e.target.value as typeof item.subscription
                      )
                    }
                    className="text-xs bg-white/5 border border-cyan-400/20 rounded-lg px-2 py-1.5 text-cyan-100 focus:outline-none"
                  >
                    {SUBS.map((s) => (
                      <option key={s.value} value={s.value} className="bg-slate-900">
                        {s.label}
                      </option>
                    ))}
                  </select>
                  <span className="ml-auto text-sm font-semibold text-cyan-300">
                    {formatMoney(item.price * item.qty, currency)}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {cart.length > 0 && (
          <div className="p-5 border-t border-cyan-400/15 space-y-3">
            <div className="flex justify-between text-cyan-100">
              <span>Subtotal</span>
              <span className="font-semibold">
                {formatMoney(subtotalINR, currency)}
              </span>
            </div>
            <Link
              href="/checkout"
              onClick={() => setDrawerOpen(false)}
              className="btn-primary rounded-xl w-full py-3.5 flex items-center justify-center text-sm"
            >
              Proceed to Checkout →
            </Link>
            <p className="text-[11px] text-center text-cyan-200/50">
              🔒 Encrypted checkout · 100% secure payment
            </p>
          </div>
        )}
      </aside>
    </>
  );
}
